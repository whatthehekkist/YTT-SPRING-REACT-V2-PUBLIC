# npm installation
- npm install npx -g
- npx create-react-app frontend
- npm install axios http-proxy-middleware react-bootstrap bootstrap react-router-dom
