package com.example.ytt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YttApplicationTests {

	@Test
	void contextLoads() {
	}

}
