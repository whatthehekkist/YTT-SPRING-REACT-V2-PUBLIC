

export const TEXTS = {
    TRANSCRIPTION_LIST: {
        heading: "Transcription List",
        desc1: "Click one of the buttons below and read the Youtube video transcription you pick.",
        desc2: "transcriptions are loaded in random by all available languages on every page refresh.",
    },
    TRANSCRIPTION: {
        heading: "Transcription",
    },
};

export default TEXTS;