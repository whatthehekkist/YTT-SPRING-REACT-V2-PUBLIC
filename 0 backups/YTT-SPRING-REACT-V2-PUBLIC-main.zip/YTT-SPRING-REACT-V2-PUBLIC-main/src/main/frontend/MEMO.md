# npm installation
- npm install npx -g
- npx create-react-app frontend
- npm install axios http-proxy-middleware react-bootstrap bootstrap react-router-dom

# reference
## blog
- https://m.blog.naver.com/sosow0212/222654483174
- https://github.com/sosow0212/restApiWithReact/tree/master
- https://github1s.com/sosow0212/restApiWithReact/tree/master
- https://enai.tistory.com/33

## docs
- https://react-bootstrap.netlify.app/docs/components/spinners/